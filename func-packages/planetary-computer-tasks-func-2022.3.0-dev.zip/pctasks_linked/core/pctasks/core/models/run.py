from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import Field, validator

from pctasks.core.models.base import PCBaseModel
from pctasks.core.models.event import CloudEvent
from pctasks.core.models.record import Record
from pctasks.core.models.task import TaskDefinition
from pctasks.core.models.utils import tzutc_now
from pctasks.core.models.workflow import (
    JobDefinition,
    WorkflowRunStatus,
    WorkflowSubmitMessage,
)
from pctasks.core.utils import StrEnum


class RunRecordType(StrEnum):
    WORKFLOW_RUN = "WorkflowRun"
    JOB_RUN = "JobRun"
    JOB_PARTITION_RUN = "JobPartitionRun"
    TASK_RUN = "TaskRun"


class TaskRunStatus(StrEnum):

    RECEIVED = "received"
    """Task run was received by the executor (e.g. Azure Batch)."""

    PENDING = "pending"
    """Task run is being processed before submission."""

    SUBMITTING = "submitting"
    """Task run is in the process of being submitted."""

    SUBMITTED = "submitted"
    """Task run was submitted to the executor (e.g. Azure Batch)."""

    STARTING = "starting"
    """Task run is starting."""

    RUNNING = "running"
    """Task run is currently running."""

    WAITING = "waiting"
    """Task is waiting for conditions to be met."""

    COMPLETING = "completing"
    """Task run was successful, awaiting orchestrator completion."""

    COMPLETED = "completed"
    """Task run is completed successfully."""

    FAILED = "failed"
    """Task run completed with failure."""

    CANCELLED = "cancelled"
    """Task run was cancelled."""


class JobPartitionRunStatus(StrEnum):
    # Keep in sync with triggers

    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PENDING = "pending"


class JobRunStatus(StrEnum):

    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    CANCELLED = "cancelled"
    PENDING = "pending"


class JobPartition(PCBaseModel):
    definition: JobDefinition
    partition_id: str


class StatusHistoryEntry(PCBaseModel):
    status: str
    timestamp: datetime


class RunRecord(Record):
    status: str
    status_history: List[StatusHistoryEntry] = []

    def set_status(self, status: str) -> None:
        self.status = status
        self.status_history.append(
            StatusHistoryEntry(status=status, timestamp=tzutc_now())
        )

    @validator("status_history", always=True)
    def _validate_status_history(
        cls, v: List[StatusHistoryEntry], values: Dict[str, Any]
    ) -> List[StatusHistoryEntry]:
        # Always ensure the status history is valid
        if not v:
            return [StatusHistoryEntry(status=values["status"], timestamp=tzutc_now())]
        return v


class TaskRunRecord(RunRecord):
    type: str = Field(default=RunRecordType.TASK_RUN, const=True)

    run_id: str
    job_id: str
    partition_id: str
    task_id: str

    status: TaskRunStatus

    log_uri: Optional[str] = None

    errors: Optional[List[str]] = None

    def get_id(self) -> str:
        return f"{self.run_id}:{self.job_id}:{self.partition_id}:{self.task_id}"

    def add_errors(self, errors: List[str]) -> None:
        if self.errors is None:
            self.errors = []
        self.errors.extend(errors)

    @classmethod
    def from_task_definition(
        cls, task_def: TaskDefinition, run_id: str, job_id: str, partition_id: str
    ) -> "TaskRunRecord":
        return cls(
            run_id=run_id,
            job_id=job_id,
            partition_id=partition_id,
            task_id=task_def.id,
            status=TaskRunStatus.PENDING,
        )


class JobPartitionRunRecord(RunRecord):
    type: str = Field(default=RunRecordType.JOB_PARTITION_RUN, const=True)

    run_id: str
    job_id: str
    partition_id: str

    status: JobPartitionRunStatus

    tasks: List[TaskRunRecord]

    def get_id(self) -> str:
        return self.id_from(
            run_id=self.run_id, job_id=self.job_id, partition_id=self.partition_id
        )

    def get_task(self, task_id: str) -> Optional[TaskRunRecord]:
        for task in self.tasks:
            if task.task_id == task_id:
                return task
        return None

    @classmethod
    def from_job_partition(
        cls,
        job_partition: JobPartition,
        run_id: str,
        status: JobPartitionRunStatus = JobPartitionRunStatus.PENDING,
    ) -> "JobPartitionRunRecord":
        job_id = job_partition.definition.get_id()
        partition_id = job_partition.partition_id
        return cls(
            status=status,
            run_id=run_id,
            job_id=job_id,
            partition_id=partition_id,
            tasks=[
                TaskRunRecord.from_task_definition(task, run_id, job_id, partition_id)
                for task in job_partition.definition.tasks
            ],
        )

    @staticmethod
    def id_from(run_id: str, job_id: str, partition_id: str) -> str:
        return f"{run_id}:{job_id}:{partition_id}"


class JobRunRecord(RunRecord):
    type: str = Field(default=RunRecordType.JOB_RUN, const=True)

    run_id: str
    job_id: str

    status: JobRunStatus

    job_partition_counts: Dict[str, int] = {
        JobPartitionRunStatus.PENDING: 0,
        JobPartitionRunStatus.RUNNING: 0,
        JobPartitionRunStatus.COMPLETED: 0,
        JobPartitionRunStatus.FAILED: 0,
        JobPartitionRunStatus.CANCELLED: 0,
    }

    errors: Optional[List[str]] = None

    def get_id(self) -> str:
        return f"{self.run_id}:{self.job_id}"

    def add_errors(self, errors: List[str]) -> None:
        if self.errors is None:
            self.errors = []
        self.errors.extend(errors)

    @classmethod
    def from_job(cls, job: JobDefinition, run_id: str) -> "JobRunRecord":
        return cls(
            run_id=run_id,
            job_id=job.get_id(),
            status=JobRunStatus.PENDING,
        )


class WorkflowRunRecord(RunRecord):
    type: str = Field(default=RunRecordType.WORKFLOW_RUN, const=True)

    dataset_id: str
    run_id: str

    status: WorkflowRunStatus

    workflow_id: str
    trigger_event: Optional[CloudEvent] = None
    args: Optional[Dict[str, Any]] = None

    log_uri: Optional[str] = None

    jobs: List[JobRunRecord]

    def get_id(self) -> str:
        return self.run_id

    def get_job_run(self, job_id: str) -> Optional[JobRunRecord]:
        for job in self.jobs:
            if job.job_id == job_id:
                return job
        return None

    @classmethod
    def from_submit_message(
        cls, submit_msg: WorkflowSubmitMessage
    ) -> "WorkflowRunRecord":
        jobs = [
            JobRunRecord.from_job(job, submit_msg.run_id)
            for job in submit_msg.workflow.definition.jobs.values()
        ]
        return cls(
            dataset_id=submit_msg.workflow.dataset_id,
            run_id=submit_msg.run_id,
            status=WorkflowRunStatus.SUBMITTED,
            workflow_id=submit_msg.workflow.id,
            trigger_event=submit_msg.trigger_event,
            args=submit_msg.args,
            jobs=jobs,
        )
