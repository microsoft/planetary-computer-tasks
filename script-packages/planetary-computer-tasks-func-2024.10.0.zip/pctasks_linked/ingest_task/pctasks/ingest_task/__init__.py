from pctasks.ingest_task.version import __version__

__all__ = ["__version__"]
