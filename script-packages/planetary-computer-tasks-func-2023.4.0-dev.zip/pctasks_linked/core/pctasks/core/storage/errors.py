class FileNotFoundError(Exception):
    pass
