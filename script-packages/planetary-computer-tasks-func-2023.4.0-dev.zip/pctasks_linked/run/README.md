# Planetary Computer Tasks: Run

This component of the PCTasks framework is around running workflows and
tasks that are submitted to the system. The `pctasks.run` library
contains functionality used to transform workflows into
Azure Batch jobs and tasks.
