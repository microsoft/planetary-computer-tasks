CREATE_CHUNKS_TASK_PATH = "pctasks.dataset.chunks.task:create_chunks_task"
LIST_CHUNKS_TASK_PATH = "pctasks.dataset.chunks.task:list_chunks_task"

ASSET_CHUNKS_PREFIX = "assets"
ITEM_CHUNKS_PREFIX = "items"

ALL_CHUNK_PREFIX = "all"
SUCCESS_CHUNK_PREFIX = "success"
FAILURE_CHUNK_PREFIX = "failed"
