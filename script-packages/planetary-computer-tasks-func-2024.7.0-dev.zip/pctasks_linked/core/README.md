# Planetary Computer Tasks: Core

This is the base library of the PCTasks framework.
It provides core functionality and base messages as
Pydantic models.

