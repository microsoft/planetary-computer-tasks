DEFAULT_CHUNK_LENGTH = 30000

CREATE_CHUNKS_TASK_ID = "create-chunks"
LIST_CHUNKS_TASK_ID = "list-chunks"
CREATE_ITEMS_TASK_ID = "create-items"

CHUNK_FOLDER = "chunks"

PROCESS_ITEMS_JOB_ID = "process_items"

DEFAULT_DATASET_YAML_PATH = "dataset.yaml"
