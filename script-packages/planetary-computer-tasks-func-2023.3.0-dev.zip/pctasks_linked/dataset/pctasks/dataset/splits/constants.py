CREATE_SPLITS_TASK_ID = "create-splits"
CREATE_SPLITS_TASK_PATH = "pctasks.dataset.splits.task:create_splits_task"
