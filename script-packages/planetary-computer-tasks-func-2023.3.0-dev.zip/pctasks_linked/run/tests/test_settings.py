from pctasks.run.settings import RunSettings


def test_settings():
    _ = RunSettings.get()
