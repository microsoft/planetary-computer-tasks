from .a import A


class B(A):
    def b(self):
        return "b"
