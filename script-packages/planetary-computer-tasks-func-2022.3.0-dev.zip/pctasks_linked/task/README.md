# Planetary Computer Tasks: Task

The pctasks.task library supplies functionality for creating executable tasks in the PCTasks system. 

