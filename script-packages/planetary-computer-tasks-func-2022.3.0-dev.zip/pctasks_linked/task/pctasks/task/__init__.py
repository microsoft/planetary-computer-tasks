""" pctasks.task

isort:skip_file
"""
from pctasks.task.version import __version__

__all__ = ["__version__"]
