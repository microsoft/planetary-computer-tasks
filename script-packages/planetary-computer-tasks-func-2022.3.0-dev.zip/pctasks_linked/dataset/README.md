# Planetary Computer Tasks: Dataset

This component of the PCTasks framework lets users create datasets by defining
configuration and specific tasks around STAC Items.