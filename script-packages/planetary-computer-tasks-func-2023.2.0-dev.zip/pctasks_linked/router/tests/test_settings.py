from pctasks.router.settings import RouterSettings


def test_settings():
    _ = RouterSettings.get()
