from pctasks.dev.mocks import MockTask


class MyMockTask(MockTask):
    pass
